# KPE Strategy Page - Installation Instructions

## Overview
Password-protected strategic plan page at `/strategy` with professional design matching your portfolio.

## Files Included
1. `page.tsx` - Main page component with password protection
2. `strategy-content.tsx` - Strategic plan content component
3. `layout.tsx` - Metadata to prevent search engine indexing
4. `ENV_TEMPLATE.txt` - Environment variable template
5. `ROBOTS_TXT_UPDATE.txt` - robots.txt addition

## Installation Steps

### Step 1: Copy Files to Your Repo
```bash
# Navigate to your portfolio repo
cd ~/path/to/your/portfolio-repo

# Create the strategy directory
mkdir -p app/strategy

# Copy the files (adjust paths as needed)
cp /path/to/downloaded/page.tsx app/strategy/
cp /path/to/downloaded/strategy-content.tsx app/strategy/
cp /path/to/downloaded/layout.tsx app/strategy/
```

### Step 2: Set Up Environment Variable
```bash
# Add to your .env.local file (create if doesn't exist)
echo "NEXT_PUBLIC_STRATEGY_PASSWORD=your_secure_password_here" >> .env.local

# Make sure .env.local is in .gitignore
echo ".env.local" >> .gitignore
```

**IMPORTANT:** Change `your_secure_password_here` to an actual secure password before deploying!

### Step 3: Update robots.txt
```bash
# Add to public/robots.txt
echo "" >> public/robots.txt
echo "# Block strategy page from search engines" >> public/robots.txt
echo "User-agent: *" >> public/robots.txt
echo "Disallow: /strategy" >> public/robots.txt
```

### Step 4: Test Locally
```bash
# Start your dev server
npm run dev

# Visit http://localhost:3000/strategy
# Test password protection
# Verify content displays correctly after login
```

### Step 5: Deploy
```bash
# Add environment variable to Netlify
# Go to: Site settings → Environment variables → Add new variable
# Key: NEXT_PUBLIC_STRATEGY_PASSWORD
# Value: your_secure_password

# Commit and push
git add app/strategy public/robots.txt
git commit -m "Add password-protected strategy page"
git push origin main

# Netlify will auto-deploy
```

## Usage

### Sharing with Investors
Share the URL and password separately:

**Example Email:**
```
Subject: KPE Strategic Plan

Hi [Investor Name],

Here's our 10-year strategic plan for KetteringPro Enterprise:

URL: https://christy.ketteringpro.com/strategy
Password: [send in separate message/text]

Best,
Christy
```

### Changing the Password
```bash
# Update in .env.local locally
NEXT_PUBLIC_STRATEGY_PASSWORD=new_password_here

# Update in Netlify:
# Site settings → Environment variables → Edit NEXT_PUBLIC_STRATEGY_PASSWORD

# Redeploy if needed
```

### Removing Password Protection
If you later want to make it public, edit `app/strategy/page.tsx`:
- Remove the password check logic
- Return `<StrategyContent />` directly
- Keep the noindex meta tags to stay out of search

## Security Notes

1. **Password in Environment Variable:**
   - Password is stored in environment variable
   - Not hardcoded in code
   - Easy to change without code changes

2. **Session-Based:**
   - Password stored in sessionStorage after correct entry
   - Persists for browser session only
   - Cleared when browser closes

3. **Search Engine Blocking:**
   - `robots.txt` blocks crawlers
   - Meta tags set to noindex/nofollow
   - Hidden from sitemaps

4. **Limitations:**
   - Client-side password check (not cryptographically secure)
   - Anyone with password can access
   - Good for investor sharing, not for highly sensitive data
   - For better security, use Netlify Identity or server-side auth

## Design Features

- Matches your portfolio dark theme
- Responsive (mobile-friendly)
- Print-friendly (investors can PDF it)
- Professional typography
- Expandable sections
- Clean tables for financial projections
- Blue accent colors matching brand

## Troubleshooting

### Password not working
- Check .env.local has correct variable name
- Restart dev server after changing .env.local
- Check Netlify environment variable is set correctly

### Page not found
- Verify files are in app/strategy/ directory
- Check Next.js app router structure
- Run `npm run dev` and check console for errors

### Styling looks off
- Verify Tailwind CSS is configured
- Check if colors match your theme
- May need to adjust color classes to match your palette

### Can't access after deployment
- Check Netlify deployment logs
- Verify environment variable is set in Netlify
- Clear browser cache and try again

## Customization

### Change Colors
Edit the color classes in `strategy-content.tsx`:
- Blue accent: `text-blue-400`, `border-blue-500`, etc.
- Background: `bg-[#0a0a0a]`, `bg-[#1a1a1a]`
- Text: `text-white`, `text-gray-300`, etc.

### Add/Remove Sections
Edit `strategy-content.tsx` and modify the section components.

### Change Password UI
Edit `page.tsx` to customize the password entry form.

## Questions?
If you need help, check:
- Next.js App Router docs
- Tailwind CSS docs
- Netlify deployment docs

---

**Document Version:** 1.0
**Created:** November 17, 2025
**For:** KetteringPro Enterprise Portfolio Site
